﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

//Serial 导入 
using System.IO.Ports;
//自己手动数据保存
using System.Runtime.InteropServices;

//自己编写的类

//创建新线程
using System.Threading;

namespace serial
{
    public partial class Form1 : Form
    {
        //全局变量缓存
        //自己手动数据保存
        [DllImport("kernel32")]
        private static extern long WritePrivateProfileString(string section, string key, string val, string filePath);//系统dll导入ini写函数
        [DllImport("kernel32")]
        private static extern int GetPrivateProfileString(string section, string key, string def, StringBuilder retVal, int size, string filePath);//系统dll导入ini读函数
        string FileName = System.AppDomain.CurrentDomain.BaseDirectory + "data.ini";//ini文件名
        StringBuilder temp = new StringBuilder(255);//存储读出ini内容变量
        string CurrentPortName;

        //接收和发送次数记忆
        int RX_CNT = 0;
        int TX_CNT = 0;

        //通信数据或调试信息显示选项
        //默认通信数据显示 0 
        byte CHN_DATA_OR_FRAME = 0;

        //帧数据命令所在位置
        byte FRAME_CMD_LOC = 1;

        //串口中断接收数据允许
        int RECE_ENABLE = 0;

        //串口数据接收
        byte[] rec_data = new byte[128];

        //常用命令
        private const int CMD_LED_TEST = 0x0001;

        //循环队列实例
        loop_queue_list<byte> queue = new loop_queue_list<byte>(128);

        //帧命令解析
        Rec_Frame_List Frame_List = new Rec_Frame_List(128);

        //委托调用
        delegate void Serial_Rece_Show();
        Serial_Rece_Show My_Serial_Rece_Show;

        public Form1()
        {
            InitializeComponent();

            //委托实例化
            My_Serial_Rece_Show = new Serial_Rece_Show(My_Serial_Rece_ShowBox);

            //自己手动添加serial recevie
            System.Windows.Forms.Control.CheckForIllegalCrossThreadCalls = false;
            //自己手动数据保存
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(My_Form1_FormClosing);

        }

        private void Div_Serial_Init()
        {
            Clear_TX_MESS();
            Clear_RX_MESS();
            textBox4.Text = "Close";
            comboBox2.Text = "115200";

            serialPort1.BaudRate = Convert.ToInt32(comboBox2.Text,10);

            //自己手动添加serial recevie
            serialPort1.ReceivedBytesThreshold = 1;

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Div_Serial_Init();
            My_Form1_FormLoad();//上电自动数据保存

            //自己手动添加serial recevie
            serialPort1.DataReceived += new SerialDataReceivedEventHandler(Div_Rece_Data);
        }

        //串口关闭时数据保存
        private void My_Form1_FormClosing(object sender, EventArgs e)
        {
            WritePrivateProfileString("FortData", "PortName", CurrentPortName, FileName);
        }

        //串口打开上次数据恢复
        private void My_Form1_FormLoad()
        {
            GetPrivateProfileString("FortData", "PortName","COM1",temp,256,FileName);
            comboBox1.Text = temp.ToString();//将之前存储的COM号当是下一次的COM号
        }

        //发送按键发送内容
        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton3.Checked)//16进制发送数据
            {
                Div_Send_Data_String(textBox5.Text, serialPort1);
            }
            else
            {
                serialPort1.WriteLine(textBox5.Text); 
            }
            TX_CNT++;
            textBox3.Text = TX_CNT.ToString();
        }

        //打开串口
        private void button2_Click(object sender, EventArgs e)
        {
            Div_Check_Serail_IsOpen(serialPort1, comboBox1, button2);
        }

        //自动扫描串口
        private void button3_Click(object sender, EventArgs e)
        {
            Div_Auto_Search_Port(serialPort1, comboBox1, 20);
        }

        //获取当前时间***********************************************************************************************

        public static string GetTimeStamp()
        {
            TimeSpan ts = DateTime.UtcNow - new DateTime(1970, 1, 1, 0, 0, 0, 0);
            return Convert.ToInt64(ts.TotalSeconds).ToString();
        }

        public static DateTime GetTime(string timeStamp)
        {
            DateTime dtStart = TimeZone.CurrentTimeZone.ToLocalTime(new DateTime(1970, 1, 1));

            long lTime = long.Parse(timeStamp + "0000000");
            TimeSpan toNow = new TimeSpan(lTime);
            return dtStart.Add(toNow);
        }

        //结束获取当前时间***********************************************************************************************

        //线程处理函数
        public void Serial_RecData_Deal()
        {
            //My_Serial_Rece_ShowBox();
        }

        //委托实际函数
        public void My_Serial_Rece_ShowBox()
        {
            if (CHN_DATA_OR_FRAME == 0)      //通信数据显示
            {
                Div_Deal_Rec_Data();
            }
            else if (CHN_DATA_OR_FRAME == 1) //数据帧显示
            {
                Div_Deal_RecFrame_Process();
            }
            else                             //其它 未实现
            { 
                
            } 
        }

        //数据接收
        private void Div_Rece_Data(object sender, SerialDataReceivedEventArgs e)
        {
            int rec_temp_len = 0;

            //线程创建
             ThreadStart entry = new ThreadStart(Serial_RecData_Deal);
             Thread WorkThread = new Thread(entry);
             //WorkThread.Start();

            if (serialPort1.IsOpen)
            {
                try
                {
                    rec_temp_len = serialPort1.BytesToRead;

                    serialPort1.Read(rec_data, 0, rec_temp_len);             //读取这么多个字节
                    queue.Insert_Queue(rec_data, rec_temp_len);              //数据入栈

                    serialPort1.DiscardInBuffer();                                          //将上次接收的数据丢弃方便下一次接收
                    Array.Clear(rec_data, 0, rec_temp_len);                                 //将上次接收的数据丢弃方便下一次接收

                    this.Invoke(My_Serial_Rece_Show, null);                   //委托
                }
                catch
                { 
                    
                }
            }
        }

        /*********************************************************************************************************************功能具体实现**/

        public void Show_Rec_Data(int temp_len, byte[] get_data, TextBox MyTextBox)
        {
            string[] temp_str = new string[128];

            RX_CNT++;
            textBox2.Text = RX_CNT.ToString();

            string datestring = GetTime(GetTimeStamp()).ToString("yyyy-MM-dd HH:mm:ss");//获取时间

            MyTextBox.AppendText("\r\n" + datestring + " < " + RX_CNT.ToString() + " > " + " >> ");

            for (int i = 0; i < temp_len; i++)
            {
                temp_str[i] = Convert.ToString(get_data[i], 16).ToUpper();//转换为大写十六进制字符串
                MyTextBox.AppendText((temp_str[i].Length == 1 ? ("0" + temp_str[i]) : temp_str[i]) + " ");
            }
        }

        public void Div_Deal_Rec_Data()
        {
            int temp_len = 0;
            byte[] get_data = new byte[128];
            string[] temp_str = new string[128];

            if (checkBox1.Checked == true)
            {
                //获取计数值
                RX_CNT++;
                textBox2.Text = RX_CNT.ToString();

                string datestring = GetTime(GetTimeStamp()).ToString("yyyy-MM-dd HH:mm:ss");//获取时间

                textBox1.AppendText("\r\n" + datestring + " < " + RX_CNT.ToString() + " > ");

                temp_len = queue.get_lenth();

                if (temp_len > 0)
                {
                    queue.Delete_Queue(get_data, temp_len);

                    if (radioButton1.Checked)//16进制接收数据
                    {
                        for (int i = 0; i < temp_len; i++)
                        {
                            temp_str[i] = Convert.ToString(get_data[i], 16).ToUpper();//转换为大写十六进制字符串
                            textBox1.AppendText((temp_str[i].Length == 1 ? ("0" + temp_str[i]) : temp_str[i]) + " ");
                        }
                    }
                    else
                    {
                        textBox1.AppendText(System.Text.Encoding.Default.GetString(get_data));
                    }
                }
                else
                { }
            }
            else
            {
                MessageBox.Show("请先勾选接收数据显示开关");
            }
        }


        //接收部分
        /*-----------------------------------------------------------
        *     帧头     命令     长度      数据      校验       帧尾
        *------------------------------------------------------------
        *    0X7E     cmd      len       N         crc        0X7F
        *------------------------------------------------------------
        *  1 byte   2 bytes    2 bytes   N bytes   1 bytes    1 byte
        */

        public bool Div_Deal_RecFrame_Data()
        {
            int temp_len = 0;
            byte temp_data = 0;
            byte[] get_data = new byte[128];

            //进来先清空之前的缓冲区
            //避免数组越界
            Frame_List.Clear_Fream();

            temp_len = queue.get_lenth();

            if (temp_len > 0)
            {
                queue.Delete_Queue(get_data, temp_len);

                for (int i = 0; i < temp_len; i++)
                {
                    temp_data = get_data[i];//获取一个数据

                    if (Frame_List.frame_header_flag < Frame_List.head[0])
                    {
                        Frame_List.Find_Frame_Header(temp_data);
                    }
                    else
                    {
                        //容易出错
                        Frame_List.frame_rbuff[Frame_List.frame_len++] = temp_data;

                        if (Frame_List.Find_Frame_tail() == 0)
                        {
                            if ((Frame_List.min_len == 0) || (Frame_List.min_len > 0) && (Frame_List.frame_len > Frame_List.min_len))
                            {
                                return true;
                            }
                            else
                            {
                                Frame_List.Clear_Fream();
                            }
                        }
                        if (Frame_List.frame_len > Frame_List.frame_size)
                        {
                            Frame_List.Clear_Fream();
                        }
                    }
                }
            }
            else
            {
                ;
            }
            return false;
        }

        public void Div_Deal_RecFrame_Process()
        {
            byte arr = 0;
            int i = 0,j = 0,k = 0;
            int temp_len = 0,temp2_len = 0;
            int temp_cmd = 0;

            byte[] data = new byte[128];
            byte[] temp_data = new byte[128];

            if (Div_Deal_RecFrame_Data() == true)
            {
                temp2_len = temp_len = Div_Data_UnEscape(Frame_List.frame_rbuff, data, Frame_List.frame_len);
                temp_cmd = ((data[FRAME_CMD_LOC] << 8) + data[FRAME_CMD_LOC+1]);

                for (i = 0; i < temp_len - 2; i++)
                { 
                    temp_data[i] = data[j+1];
                    j++;
                }
                if (Div_Data_Check_Xor(temp_data, i) != 0)
                {
                    //error
                }
                else if (((data[FRAME_CMD_LOC + 2] << 8) + data[FRAME_CMD_LOC+3]) != (temp_len - 7))
                {
                    //error
                }
                else//数据正确解析
                {
                    temp_len = ((data[FRAME_CMD_LOC + 2] << 8) + data[FRAME_CMD_LOC + 3]);

                    //显示相关内容
                    Show_Rec_Data(temp2_len, data, textBox6);

                    for (i = 0; i < temp_len; i++)
                    {
                        temp_data[i] = data[k + 5];
                        k++;
                    }
                    arr = Func_Deal(temp_cmd, temp_len, temp_data);
                }
            }
        }

        private byte Func_Deal(int cmd, int len, byte[] data)
        {
            byte value = 0;

            switch (cmd)
            {
                case CMD_LED_TEST: value = Task_0(len, data); break;
                //添加控制代码
                default: break;
            }
            return value;
        }

        private byte Task_0(int len, byte[] data)
        {
            byte[] temp_table = new byte[5];

            temp_table[0] = 0x06+1;
            temp_table[1] = 0x05;

            Div_Comm_Send_Data(0X0001, 0x0002, temp_table);

            return 0;
        }
        


        /*********************************************************************************************************************功能具体实现**/
        //自动扫描串口
        private void Div_Auto_Search_Port(SerialPort Myport, ComboBox MyBox, int num)
        {
            string str = " ";

            MyBox.Items.Clear();//清除之前的内容

            for (int i = 1; i < num; i++)//没有CMO0
            {
                try
                {
                    str = "COM" + i.ToString();
                    Myport.PortName = str;
                    Myport.Open();
                    MyBox.Items.Add(str);
                    Myport.Close();
                }
                catch
                {
                }
            }
        }

        //打开串口
        private void Div_Check_Serail_IsOpen(SerialPort Myport, ComboBox MyBox, Button MyBon)
        {
            if (MyBox.Text != " ")//确保已经选好了COM口
            {
                if (Myport.IsOpen)//关闭
                {
                    try
                    {
                        Myport.Close();
                        MyBon.Text = "打开串口";
                        textBox4.Text = "Close";
                        Clear_RX_MESS();
                        Clear_TX_MESS();
                    }
                    catch
                    { }
                }
                else
                {
                    try
                    {
                        Myport.PortName = MyBox.Text;
                        Myport.Open();
                        CurrentPortName = MyBox.Text;//存储COM号
                        MyBon.Text = "关闭串口";
                        //提示信息显示
                        textBox4.Text = MyBox.Text + "," + Myport.BaudRate.ToString() + "," + "N" + "," + Myport.DataBits.ToString() + "," + Myport.StopBits.ToString();
                    }
                    catch
                    { }
                }
            }
            else
            {
                MessageBox.Show("请选择正确COM口!");
            }
        }

        //发送字符串
        private void Div_Send_Data_String(string str,SerialPort Myport)
        {
            int i = 0;
            int num_of_page = 0;
            int num_of_singe = 0;

            byte[] Send_Buff = new byte[str.Length];

            num_of_page = str.Length / 2; //两个一组数据发送
            num_of_singe = str.Length - (num_of_page*2);//只剩下一个数据

            if (Myport.IsOpen)
            {
                if (str.Length > 0)
                {
                    try
                    {
                        if ((num_of_page == 0) && (num_of_singe > 0))//只发送一个数据
                        {
                            Send_Buff[0] = Convert.ToByte(str.Substring(0, 1), 16);
                            Myport.Write(Send_Buff, 0, 1);
                        }
                        else if ((num_of_page > 0) && (num_of_singe == 0))
                        {
                            for (i = 0; i < num_of_page; i++)//两个一组数据发送
                            {
                                Send_Buff[i] = Convert.ToByte(str.Substring(2 * i, 2), 16);
                            }
                            Myport.Write(Send_Buff, 0, num_of_page);
                        }
                        else
                        {
                            for (i = 0; i < num_of_page; i++)
                            {
                                Send_Buff[i] = Convert.ToByte(str.Substring(2 * i, 2), 16);
                            }
                            Myport.Write(Send_Buff, 0, num_of_page);

                            Send_Buff[0] = Convert.ToByte(str.Substring((2 * num_of_page), 1), 16);
                            Myport.Write(Send_Buff, 0, num_of_singe);
                        }
                    }
                    catch
                    {
                        MessageBox.Show("数据发送失败，请检查");
                    }
                }
                else
                {
                    MessageBox.Show("请填写数据后发送");
                }
            }
            else 
            {
                MessageBox.Show("请先打开串口再发送!");
            }
        }

        //发送数据
        private void Div_Send_Data(byte[] send,int len, SerialPort Myport)
        {
            if (Myport.IsOpen)
            {
                if (send.Length > 0)
                {
                    try
                    {
                        Myport.Write(send, 0, len);
                    }
                    catch
                    { }
                }
                else
                {
                    MessageBox.Show("请填写数据后发送");
                }
            }
            else
            {
                MessageBox.Show("请先打开串口再发送!");
            }
        }
 
        //异或校验
        private byte Div_Data_Check_Xor(byte[] pdat,int len)
        {
            int i = 0;
            byte sum = 0;

            for (i = 0; i < len; i++)
            {
                sum ^= pdat[i];
            }
            return (byte)sum;
        }

        //数据转义
        private int Div_Data_Escape(byte[] pin, byte[] pout, int len)
        {
            int i = 0;
            int temp_len = 0;

            for (i = 0; i < len; i++)
            {
                if ((i == 0) || (i == len - 1))
                {
                    pout[temp_len++] = pin[i];
                }
                else
                {
                    if ((pin[i] == 0x7E) || (pin[i] == 0x7F))
                    {
                        pout[temp_len++] = 0x33;
                        pout[temp_len++] = (byte)(pin[i] - (byte)0x11);
                    }
                    else
                    {
                        pout[temp_len++] = pin[i];
                    }
                }
            }
                return temp_len;
        }

        //数据反转义
        private int Div_Data_UnEscape(byte[] pin, byte[] pout, int len)
        {
            int i = 0;
            int temp_len = 0;

            for (i = 0; i < len; i++)
            {
                if (pin[i] == 0x33)
                {
                    i = i + 1;
                    pout[temp_len++] = ((byte)((pin[i]) + 0x11));
                }
                else
                {
                    pout[temp_len++] = pin[i];
                }
            }
            return temp_len;
        }

        //发送固定格式数据
        /*-----------------------------------------------------------
        *     帧头     命令     长度      数据      校验       帧尾
        *------------------------------------------------------------
        *    0X7E     cmd      len       N         crc        0X7F
        *------------------------------------------------------------
        *  1 byte   2 bytes    2 bytes   N bytes   1 bytes    1 byte
        */
        private void Div_Comm_Send_Data(int cmd, int len, byte[] pdat)
        {
            int index = 0;
            int i = 0,j = 0,k = 0;
            byte sum_crc = 0;

            byte[] temp_table = new byte[128];
            byte[] temp_table2 = new byte[128];

            temp_table[index++] = 0X7E;

            temp_table[index++] = (byte)((cmd&0xFFFF)>>8);
            temp_table[index++] = (byte)(cmd & 0xFF);

            temp_table[index++] = (byte)((len & 0xFFFF) >> 8);
            temp_table[index++] = (byte)(len & 0xFF);

            for (i = 0; i < len; i++)
            {
                temp_table[index++] = pdat[i];
            }

            for (j = 0; j < index - 1; j++)
            {
                temp_table2[j] = temp_table[k+1];
                k++;
            }

           sum_crc = (byte)Div_Data_Check_Xor(temp_table2, j);

           temp_table[index++] = sum_crc;
           temp_table[index++] = 0X7F;

           index = Div_Data_Escape(temp_table, temp_table2, index);

           Div_Send_Data(temp_table2, index, serialPort1);
        }

        //发送固定格式数据
        /*-----------------------------------------------------------
        *     帧头     命令     长度   ACK    数据      校验       帧尾
        *------------------------------------------------------------
        *    0X7E     cmd      len      1     N         crc        0X7F
        *------------------------------------------------------------
        *  1 byte   2 bytes    2 bytes   N bytes   1 bytes    1 byte
        */
        private void Div_Comm_Send_Ack_Data(int cmd, int len, byte ack,byte[] pdat)
        {
            int index = 0;
            int i = 0, j = 0, k = 0;
            byte sum_crc = 0;

            byte[] temp_table = new byte[128];
            byte[] temp_table2 = new byte[128];

            temp_table[index++] = 0X7E;

            temp_table[index++] = (byte)((cmd & 0xFFFF) >> 8);
            temp_table[index++] = (byte)(cmd & 0xFF);

            temp_table[index++] = (byte)(((len + 1) & 0xFFFF) >> 8);
            temp_table[index++] = (byte)((len + 1) & 0xFF);

            temp_table[index++] = (byte)ack;

            for (i = 0; i < len; i++)
            {
                temp_table[index++] = pdat[i];
            }

            for (j = 0; j < index - 1; j++)
            {
                temp_table2[j] = temp_table[k + 1];
                k++;
            }

            sum_crc = (byte)Div_Data_Check_Xor(temp_table2, j);

            temp_table[index++] = sum_crc;
            temp_table[index++] = 0X7F;

            index = Div_Data_Escape(temp_table, temp_table2, index);

            Div_Send_Data(temp_table2, index, serialPort1);
        }

        /************************************************************************************************************************END*/

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            //通信或是帧数据显示
            CHN_DATA_OR_FRAME = 1;

            //隐藏
            groupBox5.Hide();
            checkBox1.Enabled = false;

            groupBox2.Show();
            textBox6.Visible = true;
        }

        //通信数据显示
        private void button5_Click(object sender, EventArgs e)
        {
            //通信或是帧数据显示
            CHN_DATA_OR_FRAME = 0;

            //隐藏
            groupBox2.Hide();

            groupBox5.Show();
            checkBox1.Enabled = true;
        }

        private void button7_Click(object sender, EventArgs e)
        {

        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {

        }

        //清除发送相关信息
        private void Clear_TX_MESS()
        {
            textBox5.Text = " ";
            textBox3.Text = "0";
            TX_CNT = 0;
        }

        //清除发送相关信息
        private void Clear_RX_MESS()
        {
            textBox1.Text = " ";
            textBox2.Text = "0";
            RX_CNT = 0;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Clear_RX_MESS();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Clear_TX_MESS();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if ((RECE_ENABLE % 2) == 0)
            {
                checkBox1.Checked = true;
            }
            else
            {
                checkBox1.Checked = false;
            }
            RECE_ENABLE++;
        }

        private void 打开串口ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Div_Check_Serail_IsOpen(serialPort1, comboBox1, button2);
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }
    }
}


public class loop_queue_list<T>
{
    public int LOOP_QUEUE_SIZE_MAX;     //数组容量最大值
    public int head_pointer;            //头指针
    public int tail_pointer;            //尾指针
    public T[] array;                   //数组

    //构造函数
    public loop_queue_list(int size)
    {
        this.LOOP_QUEUE_SIZE_MAX = size;
        this.head_pointer = 0;
        this.tail_pointer = 0;
        this.array = new T[size];
    }

    public bool Insert_Queue(T value)
    {
        if ((tail_pointer + 1) % LOOP_QUEUE_SIZE_MAX == head_pointer)//满了
        {
            return false;
        }
        else
        {
            array[tail_pointer] = value;
            tail_pointer = (tail_pointer + 1) % LOOP_QUEUE_SIZE_MAX;
            return true;
        }
    }

    public void Insert_Queue(T[] pdat,int len)
    {
        for (int i = 0; i < len; i++)
        {
            if ((tail_pointer + 1) % LOOP_QUEUE_SIZE_MAX == head_pointer)//满了
            {
                return;
            }
            else
            {
                array[tail_pointer] = pdat[i];
                tail_pointer = (tail_pointer + 1) % LOOP_QUEUE_SIZE_MAX;
            }
        }
    }

    public T Delete_Queue()
    {
        T value = default(T);

        if (tail_pointer == head_pointer)//空了
        {
            return value;
        }
        else
        {
            value = array[head_pointer];
            head_pointer = (head_pointer + 1) % LOOP_QUEUE_SIZE_MAX;
            return value;
        }
    }

    public void Delete_Queue(T[] pdat, int len)
    {
        for (int i = 0; i < len; i++)
        {
            if (tail_pointer == head_pointer)//空了
            {
                return;
            }
            else
            {
                pdat[i] = array[head_pointer];
                head_pointer = (head_pointer + 1) % LOOP_QUEUE_SIZE_MAX;
            }
        }
    }

    public int get_lenth()
    {
        return ((tail_pointer + LOOP_QUEUE_SIZE_MAX - head_pointer) % LOOP_QUEUE_SIZE_MAX);
    }
}

public class Rec_Frame_List
{
    public byte[] head;                           //帧头
    public byte[] tail;                           //帧尾
    public byte min_len;                          //最小帧长度

    public byte frame_header_flag;                //帧头标志
    public byte[] frame_rbuff;                      //帧缓冲区
    public int  frame_size;                       //帧缓冲区大小
    public int  frame_len;                        //帧缓冲区长度

    //构造函数
    public Rec_Frame_List(int size)
    {
        this.head = new byte[3]{0x01,0x7E,0X00};
        this.tail = new byte[3]{0x01,0x7F,0X00};
        this.min_len = 7;
        this.frame_header_flag = 255;
        this.frame_len = 0;
        this.frame_rbuff = new byte[size];
        this.frame_size = size;
    }

    public void Clear_Fream()
    {
        frame_header_flag = 255;
        frame_len = 0;
        Array.Clear(frame_rbuff, 0, frame_size);
    }

    public void Find_Frame_Header(byte data_in)
    {
        if (head[0] <= 2)
        {
            if (data_in == (frame_rbuff[frame_header_flag+1]))
            {
                frame_rbuff[frame_len++] = data_in;
                frame_header_flag++;
                return;
            }
        }
        else
        {
        }
        Clear_Fream();
    }

    public byte Find_Frame_tail()
    {
        if (tail[0] == 1)
        {
             if(frame_rbuff[frame_len-1] == tail[1])
             {
                 return 0;
             }
        }
        else if(tail[0] == 2)
        {
            if((frame_rbuff[frame_len-2] == tail[1])&&(frame_rbuff[frame_len-1] == tail[2]))
            {
                return 0;
            }
        }
        else
        {
            return 1;
        }
        return 2;
    }

}







