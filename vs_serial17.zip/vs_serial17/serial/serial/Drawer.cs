﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace serial
{
    public partial class Drawer : Form
    {
        //自己定义
        private const int X_Unit_length = 32;                                     //X轴单位格大小
        private const int X_Num_Line = 16;                                        //X轴分段数目
        private const int X_offset = 32;                                          //X轴偏移 用于显示数字
        private const int X_Max_Limit = 256;                                     //单片机最大的数据不能超过0XFF
        private int X_Max = 256;                                                  //单片机最大的数据不能超过0XFF

        private const int Y_Unit_length = 32;                                     //Y轴单位格大小
        private const int Y_Num_Line = 16;                                        //Y轴分段数目
        private const int Y_offset = 32;                                          //X轴偏移 用于显示数字
        private const int Y_Max_Limit = 256;                                     //单片机最大的数据不能超过0XFF
        private int Y_Max = 128;                                                  //Y轴最大数值

        private const int StepValue = 8;                                         //步进值

        private List<byte> DataList = new List<byte>();                         //数据结构----线性链表

        private Pen TablePen = new Pen(Color.FromArgb(0x00, 0x00, 0x00));       //轴线颜色
        private Pen LinesPen = new Pen(Color.FromArgb(0xa0, 0x00, 0x00));       //波形颜色

        //快捷键设置
        private bool KeyShift, KeyShowMain, KeyHideMain, KeyExit, KeyOpen, KeyClose, KeyStepUp, KeyStepDown;

        public Drawer()
        {
            //开启双缓冲
            this.SetStyle(ControlStyles.DoubleBuffer | ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint,true);
            //更新双缓存
            this.UpdateStyles();

            InitializeComponent();
        }

        private void Drawer_Load(object sender, EventArgs e)
        {

        }

        //向线性链表尾部追加数据
        //Form1.cs被调用

        public void AddData(byte[] Data)
        {
            for (int i = 0; i < Data.Length; i++)
            {
                DataList.Add(Data[i]);
            }
            Invalidate();//刷新显示
        }

        //画背景颜色
        private void Draw_BackGround(object sender, PaintEventArgs e)
        {
            e.Graphics.FillRectangle(Brushes.BlueViolet, X_offset, Y_offset, Y_Num_Line * Y_Unit_length,X_Num_Line * X_Unit_length);
        }

        //画格子，标数字
        //在 Dramer.Designer.cs 被调用
        private void Form2_Paint(object sender, PaintEventArgs e)
        {
            //显示坐标系相关
            String str = " ";

            //坐标计算相关
            int num_of_page = 0;
            int num_of_singe = 0;
            int temp = 0;
            int temp2 = 0;

            System.Drawing.Drawing2D.GraphicsPath gp = new System.Drawing.Drawing2D.GraphicsPath();

            if (X_Max > X_Max_Limit)X_Max = X_Max_Limit;

            //背景颜色
            Draw_BackGround(sender,e);
            //打点
            TablePen.DashStyle = System.Drawing.Drawing2D.DashStyle.Dot;

            //Draw Y 纵向轴绘制
            for (int i = 0; i < Y_Num_Line; i++)//多少条线
            {
                e.Graphics.DrawLine(TablePen, X_offset + X_Unit_length + i * X_Unit_length, Y_offset, X_offset + X_Unit_length + i * X_Unit_length,  (X_Num_Line * X_Unit_length)+Y_offset);//画线
            }

           //底下显示内容
           for (int i = 0; i <= Y_Num_Line; i++)
            {
                str = (i * (Y_Max / Y_Num_Line)).ToString();
                gp.AddString(str, this.Font.FontFamily, (int)FontStyle.Italic, 12, new RectangleF((X_offset + i * X_Unit_length) - 8, (X_Num_Line * X_Unit_length) + Y_offset, 400, 20), null);//添加文字
            }

            //Draw X 横向轴绘制
            for (int i = 0; i < X_Num_Line; i++)
            {
                e.Graphics.DrawLine(TablePen, X_offset, Y_offset + Y_Unit_length + i * Y_Unit_length, X_offset + (Y_Unit_length*Y_Num_Line), Y_offset + Y_Unit_length + i * Y_Unit_length);
            }

            //底下显示内容
            for (int i = 0; i <= X_Num_Line; i++)
            {
               str = ((X_Num_Line - i) * (X_Max / X_Num_Line)).ToString(); 
               gp.AddString(str, this.Font.FontFamily, (int)FontStyle.Italic, 12, new RectangleF(0, (i * Y_Unit_length) + Y_offset - 6, 400, 20), null);//添加文字
             }
            
            //文字写入
            e.Graphics.DrawPath(Pens.Black, gp);

            //如果数据量大于可容纳的数据量，即删除最左数据
            if (DataList.Count - 1 >= ((Y_Num_Line * Y_Unit_length) - Y_offset) / StepValue)
            {
                DataList.RemoveRange(0, DataList.Count - (((Y_Num_Line * Y_Unit_length) - Y_offset) / StepValue) - 1);
            }

            /*以0-128为例                            对应坐标 (X轴) (每隔32个坐标为一行)
             |128_________________________________   Y_offset =32
             ...                                    ...
             |56___________________________________ ... 
             |48___________________________________ ...         
             |36___________________________________ 416
             |24___________________________________ 448
             |16___________________________________ 480
             |8___________________________________  (X_Num_Line + 1) * X_Unit_length) - Y_offset = 544 - 32 = 512
             |0___________________________________  (X_Num_Line + 1) * X_Unit_length) = （16+1）* 32 = 544
             
             具体坐标计算公式如下
             ((X_Num_Line + 1) * X_Unit_length) - (Y_offset * num_of_page + num_of_singe * (X_Unit_length / (X_Max / (X_Num_Line + 1))));
              */

            /*分情况讨论 存在问题
             (1) X_Max/X_Num_Line = 整数
             (2) X_Max/X_Num_Line = 有小数的 导致最后一个数计算错误（最大那个数）
             (3) 1024就不对
             */

            for (int i = 0; i < DataList.Count - 1; i++)//绘制
            {
                if (DataList[i] >= (X_Num_Line * (X_Max / X_Num_Line)))//数据限制 数据输入不检查
                {
                    DataList[i] = (byte)(X_Num_Line * (X_Max / X_Num_Line));
                    num_of_page = X_Num_Line;
                    num_of_singe = 0;
                }
                else
                {
                    num_of_page = DataList[i] / (X_Max / X_Num_Line);//得到整数部分
                    num_of_singe = DataList[i] % (X_Max / X_Num_Line);//得到余数
                }
                temp = ((X_Num_Line + 1) * X_Unit_length) - (Y_offset * num_of_page + num_of_singe * (X_Unit_length / (X_Max / (X_Num_Line + 1))));

                if (DataList[i + 1] >= (X_Num_Line * (X_Max / X_Num_Line)))
                {
                    DataList[i + 1] = (byte)(X_Num_Line * (X_Max / X_Num_Line));
                    num_of_page = X_Num_Line;
                    num_of_singe = 0;
                }
                else
                {
                    num_of_page = DataList[i+1] / (X_Max / X_Num_Line);//得到整数部分
                    num_of_singe = DataList[i+1] % (X_Max / X_Num_Line);//得到余数
                }

                temp2 = ((X_Num_Line + 1) * X_Unit_length) - (Y_offset * num_of_page + num_of_singe * (X_Unit_length / (X_Max / (X_Num_Line + 1))));

                //绘图
                e.Graphics.DrawLine(LinesPen, Y_offset + i * StepValue, temp, Y_offset + (i + 1) * StepValue, temp2);
            }
        }
        private void Drawer_FormClosing(object sender, FormClosingEventArgs e)
        {
          
        }
    }
}
